/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/*
 * Copyright (c) 2020-2021, The Linux Foundation. All rights reserved.
 * Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
 */
#ifndef __MMM_COLOR_FMT_INFO_H__
#define __MMM_COLOR_FMT_INFO_H__

/* Width and Height should be multiple of 16 */
#define INTERLACE_WIDTH_MAX 1920
#define INTERLACE_HEIGHT_MAX 1920
#define INTERLACE_MB_PER_FRAME_MAX ((1920*1088)/256)

#ifndef MMM_COLOR_FMT_ALIGN
#define MMM_COLOR_FMT_ALIGN(__sz, __align) (((__align) & ((__align) - 1)) ?\
	((((__sz) + (__align) - 1) / (__align)) * (__align)) :\
	(((__sz) + (__align) - 1) & (~((__align) - 1))))
#endif

#ifndef MMM_COLOR_FMT_ROUNDUP
#define MMM_COLOR_FMT_ROUNDUP(__sz, __r) (((__sz) + ((__r) - 1)) / (__r))
#endif

enum mmm_color_fmts {
	/* Venus NV12:
	 * YUV 4:2:0 image with a plane of 8 bit Y samples followed
	 * by an interleaved U/V plane containing 8 bit 2x2 subsampled
	 * colour difference samples.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * U V U V U V U V U V U V . . . .  ^
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride : Width aligned to 128
	 * UV_Stride : Width aligned to 128
	 * Y_Scanlines: Height aligned to 32
	 * UV_Scanlines: Height/2 aligned to 16
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_NV12,
	/* Venus NV21:
	 * YUV 4:2:0 image with a plane of 8 bit Y samples followed
	 * by an interleaved V/U plane containing 8 bit 2x2 subsampled
	 * colour difference samples.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * V U V U V U V U V U V U . . . .  ^
	 * V U V U V U V U V U V U . . . .  |
	 * V U V U V U V U V U V U . . . .  |
	 * V U V U V U V U V U V U . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  --> Padding & Buffer size alignment
	 *
	 * Y_Stride : Width aligned to 128
	 * UV_Stride : Width aligned to 128
	 * Y_Scanlines: Height aligned to 32
	 * UV_Scanlines: Height/2 aligned to 16
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_NV21,
	/*
	 * The buffer can be of 2 types:
	 * (1) Venus NV12 UBWC Progressive
	 * (2) Venus NV12 UBWC Interlaced
	 *
	 * (1) Venus NV12 UBWC Progressive Buffer Format:
	 * Compressed Macro-tile format for NV12.
	 * Contains 4 planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 * (C) UV_Meta_Plane
	 * (D) UV_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 8 bit Y samples.
	 *
	 * UV_Meta_Plane consists of meta information to decode compressed
	 * tile data in UV_UBWC_Plane.
	 * UV_UBWC_Plane consists of UV data in compressed macro-tile format.
	 * UBWC decoder block will use UV_Meta_Plane data together with
	 * UV_UBWC_Plane data to produce loss-less uncompressed 8 bit 2x2
	 * subsampled color difference samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----- UV_Meta_Stride ---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <--Compressed tile UV Stride--->
	 * U* V* U* V* U* V* U* V* . . . .  ^
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 *
	 * Y_Stride = align(Width, 128)
	 * UV_Stride = align(Width, 128)
	 * Y_Scanlines = align(Height, 32)
	 * UV_Scanlines = align(Height/2, 32)
	 * Y_UBWC_Plane_size = align(Y_Stride * Y_Scanlines, 4096)
	 * UV_UBWC_Plane_size = align(UV_Stride * UV_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 16)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 * UV_Meta_Stride = align(roundup(Width, UV_TileWidth), 64)
	 * UV_Meta_Scanlines = align(roundup(Height, UV_TileHeight), 16)
	 * UV_Meta_Plane_size = align(UV_Meta_Stride * UV_Meta_Scanlines, 4096)
	 *
	 * Total size = align( Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 *
	 *
	 * (2) Venus NV12 UBWC Interlaced Buffer Format:
	 * Compressed Macro-tile format for NV12 interlaced.
	 * Contains 8 planes in the following order -
	 * (A) Y_Meta_Top_Field_Plane
	 * (B) Y_UBWC_Top_Field_Plane
	 * (C) UV_Meta_Top_Field_Plane
	 * (D) UV_UBWC_Top_Field_Plane
	 * (E) Y_Meta_Bottom_Field_Plane
	 * (F) Y_UBWC_Bottom_Field_Plane
	 * (G) UV_Meta_Bottom_Field_Plane
	 * (H) UV_UBWC_Bottom_Field_Plane
	 * Y_Meta_Top_Field_Plane consists of meta information to decode
	 * compressed tile data for Y_UBWC_Top_Field_Plane.
	 * Y_UBWC_Top_Field_Plane consists of Y data in compressed macro-tile
	 * format for top field of an interlaced frame.
	 * UBWC decoder block will use the Y_Meta_Top_Field_Plane data together
	 * with Y_UBWC_Top_Field_Plane data to produce loss-less uncompressed
	 * 8 bit Y samples for top field of an interlaced frame.
	 *
	 * UV_Meta_Top_Field_Plane consists of meta information to decode
	 * compressed tile data in UV_UBWC_Top_Field_Plane.
	 * UV_UBWC_Top_Field_Plane consists of UV data in compressed macro-tile
	 * format for top field of an interlaced frame.
	 * UBWC decoder block will use UV_Meta_Top_Field_Plane data together
	 * with UV_UBWC_Top_Field_Plane data to produce loss-less uncompressed
	 * 8 bit subsampled color difference samples for top field of an
	 * interlaced frame.
	 *
	 * Each tile in Y_UBWC_Top_Field_Plane/UV_UBWC_Top_Field_Plane is
	 * independently decodable and randomly accessible. There is no
	 * dependency between tiles.
	 *
	 * Y_Meta_Bottom_Field_Plane consists of meta information to decode
	 * compressed tile data for Y_UBWC_Bottom_Field_Plane.
	 * Y_UBWC_Bottom_Field_Plane consists of Y data in compressed macro-tile
	 * format for bottom field of an interlaced frame.
	 * UBWC decoder block will use the Y_Meta_Bottom_Field_Plane data
	 * together with Y_UBWC_Bottom_Field_Plane data to produce loss-less
	 * uncompressed 8 bit Y samples for bottom field of an interlaced frame.
	 *
	 * UV_Meta_Bottom_Field_Plane consists of meta information to decode
	 * compressed tile data in UV_UBWC_Bottom_Field_Plane.
	 * UV_UBWC_Bottom_Field_Plane consists of UV data in compressed
	 * macro-tile format for bottom field of an interlaced frame.
	 * UBWC decoder block will use UV_Meta_Bottom_Field_Plane data together
	 * with UV_UBWC_Bottom_Field_Plane data to produce loss-less
	 * uncompressed 8 bit subsampled color difference samples for bottom
	 * field of an interlaced frame.
	 *
	 * Each tile in Y_UBWC_Bottom_Field_Plane/UV_UBWC_Bottom_Field_Plane is
	 * independently decodable and randomly accessible. There is no
	 * dependency between tiles.
	 *
	 * <-----Y_TF_Meta_Stride---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . . Half_height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_TF_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-Compressed tile Y_TF Stride->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . . Half_height  |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_TF_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----UV_TF_Meta_Stride---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_TF_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <-Compressed tile UV_TF Stride->
	 * U* V* U* V* U* V* U* V* . . . .  ^
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  UV_TF_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * <-----Y_BF_Meta_Stride---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . . Half_height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_BF_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-Compressed tile Y_BF Stride->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . . Half_height  |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_BF_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----UV_BF_Meta_Stride---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_BF_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <-Compressed tile UV_BF Stride->
	 * U* V* U* V* U* V* U* V* . . . .  ^
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  UV_BF_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 *
	 * Half_height = (Height+1)>>1
	 * Y_TF_Stride = align(Width, 128)
	 * UV_TF_Stride = align(Width, 128)
	 * Y_TF_Scanlines = align(Half_height, 32)
	 * UV_TF_Scanlines = align((Half_height+1)/2, 32)
	 * Y_UBWC_TF_Plane_size = align(Y_TF_Stride * Y_TF_Scanlines, 4096)
	 * UV_UBWC_TF_Plane_size = align(UV_TF_Stride * UV_TF_Scanlines, 4096)
	 * Y_TF_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_TF_Meta_Scanlines = align(roundup(Half_height, Y_TileHeight), 16)
	 * Y_TF_Meta_Plane_size =
	 *     align(Y_TF_Meta_Stride * Y_TF_Meta_Scanlines, 4096)
	 * UV_TF_Meta_Stride = align(roundup(Width, UV_TileWidth), 64)
	 * UV_TF_Meta_Scanlines = align(roundup(Half_height, UV_TileHeight), 16)
	 * UV_TF_Meta_Plane_size =
	 *     align(UV_TF_Meta_Stride * UV_TF_Meta_Scanlines, 4096)
	 * Y_BF_Stride = align(Width, 128)
	 * UV_BF_Stride = align(Width, 128)
	 * Y_BF_Scanlines = align(Half_height, 32)
	 * UV_BF_Scanlines = align((Half_height+1)/2, 32)
	 * Y_UBWC_BF_Plane_size = align(Y_BF_Stride * Y_BF_Scanlines, 4096)
	 * UV_UBWC_BF_Plane_size = align(UV_BF_Stride * UV_BF_Scanlines, 4096)
	 * Y_BF_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_BF_Meta_Scanlines = align(roundup(Half_height, Y_TileHeight), 16)
	 * Y_BF_Meta_Plane_size =
	 *     align(Y_BF_Meta_Stride * Y_BF_Meta_Scanlines, 4096)
	 * UV_BF_Meta_Stride = align(roundup(Width, UV_TileWidth), 64)
	 * UV_BF_Meta_Scanlines = align(roundup(Half_height, UV_TileHeight), 16)
	 * UV_BF_Meta_Plane_size =
	 *     align(UV_BF_Meta_Stride * UV_BF_Meta_Scanlines, 4096)
	 *
	 * Total size = align( Y_UBWC_TF_Plane_size + UV_UBWC_TF_Plane_size +
	 *           Y_TF_Meta_Plane_size + UV_TF_Meta_Plane_size +
	 *			 Y_UBWC_BF_Plane_size + UV_UBWC_BF_Plane_size +
	 *           Y_BF_Meta_Plane_size + UV_BF_Meta_Plane_size +, 4096)
	 */
	MMM_COLOR_FMT_NV12_UBWC,
	/* Venus NV12 10-bit UBWC:
	 * Compressed Macro-tile format for NV12.
	 * Contains 4 planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 * (C) UV_Meta_Plane
	 * (D) UV_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 10 bit Y samples.
	 *
	 * UV_Meta_Plane consists of meta information to decode compressed
	 * tile data in UV_UBWC_Plane.
	 * UV_UBWC_Plane consists of UV data in compressed macro-tile format.
	 * UBWC decoder block will use UV_Meta_Plane data together with
	 * UV_UBWC_Plane data to produce loss-less uncompressed 10 bit 2x2
	 * subsampled color difference samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ----->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----- UV_Meta_Stride ---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <--Compressed tile UV Stride--->
	 * U* V* U* V* U* V* U* V* . . . .  ^
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 *
	 *
	 * Y_Stride = align(Width * 4/3, 256)
	 * UV_Stride = align(Width * 4/3, 256)
	 * Y_Scanlines = align(Height, 32)
	 * UV_Scanlines = align(Height/2, 16)
	 * Y_UBWC_Plane_Size = align(Y_Stride * Y_Scanlines, 4096)
	 * UV_UBWC_Plane_Size = align(UV_Stride * UV_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 16)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 * UV_Meta_Stride = align(roundup(Width, UV_TileWidth), 64)
	 * UV_Meta_Scanlines = align(roundup(Height, UV_TileHeight), 16)
	 * UV_Meta_Plane_size = align(UV_Meta_Stride * UV_Meta_Scanlines, 4096)
	 *
	 * Total size = align(Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_NV12_BPP10_UBWC,
	/* Venus RGBA8888 format:
	 * Contains 1 plane in the following order -
	 * (A) RGBA plane
	 *
	 * <-------- RGB_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height      |
	 * R R R R R R R R R R R R . . . .  |       RGB_Scanlines
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGB_Stride = align(Width * 4, 256)
	 * RGB_Scanlines = align(Height, 32)
	 * RGB_Plane_size = align(RGB_Stride * RGB_Scanlines, 4096)
	 *
	 * Total size = align(RGB_Plane_size , 4096)
	 */
	MMM_COLOR_FMT_RGBA8888,
	/* Venus RGBA8888 UBWC format:
	 * Contains 2 planes in the following order -
	 * (A) Meta plane
	 * (B) RGBA plane
	 *
	 * <--- RGB_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |       Meta_RGB_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-------- RGB_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height      |
	 * R R R R R R R R R R R R . . . .  |       RGB_Scanlines
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .    -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGB_Stride = align(Width * 4, 256)
	 * RGB_Scanlines = align(Height, 16)
	 * RGB_Plane_size = align(RGB_Stride * RGB_Scanlines, 4096)
	 * RGB_Meta_Stride = align(roundup(Width, RGB_TileWidth), 64)
	 * RGB_Meta_Scanline = align(roundup(Height, RGB_TileHeight), 16)
	 * RGB_Meta_Plane_size = align(RGB_Meta_Stride *
	 *		RGB_Meta_Scanlines, 4096)
	 *
	 * Total size = align(RGB_Meta_Plane_size + RGB_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_RGBA8888_UBWC,
	/* Venus RGBA1010102 UBWC format:
	 * Contains 2 planes in the following order -
	 * (A) Meta plane
	 * (B) RGBA plane
	 *
	 * <--- RGB_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |       Meta_RGB_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-------- RGB_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height      |
	 * R R R R R R R R R R R R . . . .  |       RGB_Scanlines
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .    -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGB_Stride = align(Width * 4, 256)
	 * RGB_Scanlines = align(Height, 16)
	 * RGB_Plane_size = align(RGB_Stride * RGB_Scanlines, 4096)
	 * RGB_Meta_Stride = align(roundup(Width, RGB_TileWidth), 64)
	 * RGB_Meta_Scanline = align(roundup(Height, RGB_TileHeight), 16)
	 * RGB_Meta_Plane_size = align(RGB_Meta_Stride *
	 *		RGB_Meta_Scanlines, 4096)
	 *
	 * Total size = align(RGB_Meta_Plane_size + RGB_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_RGBA1010102_UBWC,
	/* Venus RGB565 UBWC format:
	 * Contains 2 planes in the following order -
	 * (A) Meta plane
	 * (B) RGB plane
	 *
	 * <--- RGB_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |       Meta_RGB_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-------- RGB_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height      |
	 * R R R R R R R R R R R R . . . .  |       RGB_Scanlines
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .    -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGB_Stride = align(Width * 2, 256)
	 * RGB_Scanlines = align(Height, 16)
	 * RGB_Plane_size = align(RGB_Stride * RGB_Scanlines, 4096)
	 * RGB_Meta_Stride = align(roundup(Width, RGB_TileWidth), 64)
	 * RGB_Meta_Scanline = align(roundup(Height, RGB_TileHeight), 16)
	 * RGB_Meta_Plane_size = align(RGB_Meta_Stride *
	 *		RGB_Meta_Scanlines, 4096)
	 *
	 * Total size = align(RGB_Meta_Plane_size + RGB_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_RGB565_UBWC,
	/* P010 UBWC:
	 * Compressed Macro-tile format for NV12.
	 * Contains 4 planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 * (C) UV_Meta_Plane
	 * (D) UV_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 10 bit Y samples.
	 *
	 * UV_Meta_Plane consists of meta information to decode compressed
	 * tile data in UV_UBWC_Plane.
	 * UV_UBWC_Plane consists of UV data in compressed macro-tile format.
	 * UBWC decoder block will use UV_Meta_Plane data together with
	 * UV_UBWC_Plane data to produce loss-less uncompressed 10 bit 2x2
	 * subsampled color difference samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ----->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----- UV_Meta_Stride ---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <--Compressed tile UV Stride--->
	 * U* V* U* V* U* V* U* V* . . . .  ^
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 *
	 *
	 * Y_Stride = align(Width * 2, 256)
	 * UV_Stride = align(Width * 2, 256)
	 * Y_Scanlines = align(Height, 16)
	 * UV_Scanlines = align(Height/2, 16)
	 * Y_UBWC_Plane_Size = align(Y_Stride * Y_Scanlines, 4096)
	 * UV_UBWC_Plane_Size = align(UV_Stride * UV_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 16)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 * UV_Meta_Stride = align(roundup(Width, UV_TileWidth), 64)
	 * UV_Meta_Scanlines = align(roundup(Height, UV_TileHeight), 16)
	 * UV_Meta_Plane_size = align(UV_Meta_Stride * UV_Meta_Scanlines, 4096)
	 *
	 * Total size = align(Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_P010_UBWC,
	/* Venus P010:
	 * YUV 4:2:0 image with a plane of 10 bit Y samples followed
	 * by an interleaved U/V plane containing 10 bit 2x2 subsampled
	 * colour difference samples.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * U V U V U V U V U V U V . . . .  ^
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride : Width * 2 aligned to 256
	 * UV_Stride : Width * 2 aligned to 256
	 * Y_Scanlines: Height aligned to 32
	 * UV_Scanlines: Height/2 aligned to 16
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_P010,
	/* Venus P010_512:
	 * YUV 4:2:0 image with a plane of 10 bit Y samples followed
	 * by an interleaved U/V plane containing 10 bit 2x2 subsampled
	 * colour difference samples.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * U V U V U V U V U V U V . . . .  ^
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride : Width * 2 aligned to 512
	 * UV_Stride : Width * 2 aligned to 512
	 * Y_Scanlines: Height aligned to 32
	 * UV_Scanlines: Height/2 aligned to 16
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_P010_512,
	/* Venus NV12_512:
	 * YUV 4:2:0 image with a plane of 8 bit Y samples followed
	 * by an interleaved U/V plane containing 8 bit 2x2 subsampled
	 * colour difference samples.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * U V U V U V U V U V U V . . . .  ^
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride : Width aligned to 512
	 * UV_Stride : Width aligned to 512
	 * Y_Scanlines: Height aligned to 512
	 * UV_Scanlines: Height/2 aligned to 256
	 * Total size = align((Y_Stride * Y_Scanlines
	 *          + UV_Stride  * UV_Scanlines), 4096)
	 */
	MMM_COLOR_FMT_NV12_512,
	/* Venus RGBA FP16 UBWC:
	 * Contains 2 planes in the following order -
	 * (A) Meta plane
	 * (B) RGBA plane
	 *
	 * <--- RGB_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |       Meta_RGB_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-------- RGB_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height      |
	 * R R R R R R R R R R R R . . . .  |       RGB_Scanlines
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .    -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGB_Stride = align(Width * 8, 256)
	 * RGB_Scanlines = align(Height, 16)
	 * RGB_Plane_size = align(RGB_Stride * RGB_Scanlines, 4096)
	 * RGB_Meta_Stride = align(roundup(Width, RGB_TileWidth), 64)
	 * RGB_Meta_Scanline = align(roundup(Height, RGB_TileHeight), 16)
	 * RGB_Meta_Plane_size = align(RGB_Meta_Stride *
	 *              RGB_Meta_Scanlines, 4096)
	 * RGB_TileWidth = 8 pixels across is 1 tile
	 * RGB_TileHeight = 4 pixels
	 * Total size = align(RGB_Meta_Plane_size + RGB_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_RGBA16161616F_UBWC,
	/* RGBA8888_L_8_5 UBWC format:
	 * Contains 2 planes in the following order -
	 * (A) Meta plane
	 * (B) RGBA plane
	 *
	 * <--- RGBA_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |       Meta_RGBA_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-------- RGBA_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height      |
	 * R R R R R R R R R R R R . . . .  |       RGBA_Scanlines
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .    -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGBA_Stride = align(Width * 4, 256)
	 * RGBA_Scanlines = align(Height, 16)
	 * RGBA_Plane_size = align(RGBA_Stride * RGBA_Scanlines, 4096)
	 * RGBA_Meta_Stride = align(roundup(Width, RGBA_TileWidth), 64)
	 * RGBA_Meta_Scanline = align(roundup(Height, RGBA_TileHeight), 16)
	 * RGBA_Meta_Plane_size = align(RGBA_Meta_Stride *
	 *		RGBA_Meta_Scanlines, 4096)
	 *
	 * Total size = align(RGBA_Meta_Plane_size + RGBA_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_RGBA8888_L_8_5_UBWC,
	/* RGBA8888 UBWC format:
	 * Contains 2 planes in the following order -
	 * (A) Meta plane
	 * (B) RGBA plane
	 *
	 * <--- RGBA_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height/2    |
	 * M M M M M M M M M M M M . .      |       Meta_RGBA_Scanlines
	 * . . . . . . . . . . . . . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <-------- RGBA_Stride -------->
	 * <------- Width ------->
	 * R R R R R R R R R R R R . . . .  ^           ^
	 * R R R R R R R R R R R R . . . .  |           |
	 * R R R R R R R R R R R R . . . .  Height/2    |
	 * R R R R R R R R R R R R . . . .  |       RGBA_Scanlines
	 * . . . . . . . . . . . . . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .    -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * RGBA_Stride = align(Width * 4, 256)
	 * RGBA_Scanlines = align(Height/2, 16)
	 * RGBA_Plane_size = align(RGBA_Stride * RGBA_Scanlines, 4096)
	 * RGBA_Meta_Stride = align(roundup(Width, RGBA_TileWidth), 64)
	 * RGBA_Meta_Scanline = align(roundup(Height, RGBA_TileHeight), 16)
	 * RGBA_Meta_Plane_size = align(RGBA_Meta_Stride *
	 *		RGBA_Meta_Scanlines, 4096)
	 *
	 * Total size = align(RGBA_Meta_Plane_size + RGBA_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_RGBA8888_L_2_1_UBWC,
	/*
	 *
	 * (1) Venus NV124R UBWC Progressive Buffer Format:
	 * Compressed Macro-tile format for NV12.
	 * Contains 4 planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 * (C) UV_Meta_Plane
	 * (D) UV_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 8 bit Y samples.
	 *
	 * UV_Meta_Plane consists of meta information to decode compressed
	 * tile data in UV_UBWC_Plane.
	 * UV_UBWC_Plane consists of UV data in compressed macro-tile format.
	 * UBWC decoder block will use UV_Meta_Plane data together with
	 * UV_UBWC_Plane data to produce loss-less uncompressed 8 bit 2x2
	 * subsampled color difference samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ---->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----- UV_Meta_Stride ---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <--Compressed tile UV Stride--->
	 * U* V* U* V* U* V* U* V* . . . .  ^
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  |
	 * U* V* U* V* U* V* U* V* . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 *
	 * Y_Stride = align(Width, 256)
	 * UV_Stride = align(Width, 256)
	 * Y_Scanlines = align(Height, 16)
	 * UV_Scanlines = align(Height/2, 16)
	 * Y_UBWC_Plane_size = align(Y_Stride * Y_Scanlines, 4096)
	 * UV_UBWC_Plane_size = align(UV_Stride * UV_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 4)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 * UV_Meta_Stride = align(roundup(Width, UV_TileWidth), 64)
	 * UV_Meta_Scanlines = align(roundup(Height, UV_TileHeight), 4)
	 * UV_Meta_Plane_size = align(UV_Meta_Stride * UV_Meta_Scanlines, 4096)
	 *
	 * Total size = align( Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_NV124R_UBWC,
	/* P210 UBWC:
	 * Compressed Macro-tile format for P210.
	 * Contains 4 planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 * (C) UV_Meta_Plane
	 * (D) UV_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 10 bit Y samples.
	 *
	 * UV_Meta_Plane consists of meta information to decode compressed
	 * tile data in UV_UBWC_Plane.
	 * UV_UBWC_Plane consists of UV data in compressed macro-tile format.
	 * UBWC decoder block will use UV_Meta_Plane data together with
	 * UV_UBWC_Plane data to produce loss-less uncompressed 10 bit 2x1
	 * subsampled color difference samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ----->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 * <----- UV_Meta_Stride ---->
	 * M M M M M M M M M M M M . .      ^
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      |
	 * M M M M M M M M M M M M . .      M_UV_Scanlines
	 * . . . . . . . . . . . . . .      |
	 * . . . . . . . . . . . . . .      V
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * <--Compressed tile UV Stride--->
	 * U*V* U*V* U*V* U*V* . . . . . .  ^
	 * U*V* U*V* U*V* U*V* . . . . . .  |
	 * U*V* U*V* U*V* U*V* . . . . . .  |
	 * U*V* U*V* U*V* U*V* . . . . . .  UV_Scanlines
	 * U*V* U*V* U*V* U*V* . . . . . .  |
	 * U*V* U*V* U*V* U*V* . . . . . .  |
	 * U*V* U*V* U*V* U*V* . . . . . .  |
	 * U*V* U*V* U*V* U*V* . . . . . .  |
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 *
	 *
	 * Y_Stride = align(Width * 2, 256)
	 * UV_Stride = align(Width * 2, 256)
	 * Y_Scanlines = align(Height, 16)
	 * UV_Scanlines = align(Height, 16)
	 * Y_UBWC_Plane_Size = align(Y_Stride * Y_Scanlines, 4096)
	 * UV_UBWC_Plane_Size = align(UV_Stride * UV_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 16)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 * UV_Meta_Stride = align(roundup(Width/2, UV_TileWidth), 64)
	 * UV_Meta_Scanlines = align(roundup(Height, UV_TileHeight), 16)
	 * UV_Meta_Plane_size = align(UV_Meta_Stride * UV_Meta_Scanlines, 4096)
	 *
	 * Total size = align(Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_P210_UBWC,
	/* P210:
	 * YUV 4:2:2 image with a plane of 10 bit Y samples followed
	 * by an interleaved U/V plane containing 10 bit 2x1 subsampled
	 * colour difference samples.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y0 Y1 Y2 Y3 Y4 Y5 Y6 Y7 . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * U0 V0 U2 V2 U4 V4 U6 V6 . . . .  ^
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  |
	 * U V U V U V U V U V U V . . . .  UV_Scanlines
	 * . . . . . . . . . . . . . . . .  |
	 * . . . . . . . . . . . . . . . .  V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride = align(Width * 2, 256)
	 * UV_Stride = align(Width * 2, 256)
	 * Y_Scanlines = align(Height, 16)
	 * UV_Scanlines = align(Height, 16)
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_P210,
	/* Venus P010_Y:
	 * YUV 4:2:0 image with a plane of 10 bit Y samples with
	 * no following UV plane.
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride : Width * 2 aligned to 256
	 * UV_Stride : Width * 2 aligned to 256
	 * Y_Scanlines: Height aligned to 32
	 * UV_Scanlines: Height/2 aligned to 16
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_P010_Y,
	/* Venus P010_A:
	 * YUV 4:2:0 image with a plane of 10 bit A samples with
	 *
	 * <-------- Y/UV_Stride -------->
	 * <------- Width ------->
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  ^           ^
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  Height      |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |          Y_Scanlines
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  |           |
	 * Y Y Y Y Y Y Y Y Y Y Y Y . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              V
	 * . . . . . . . . . . . . . . . .  --> Buffer size alignment
	 *
	 * Y_Stride : Width * 2 aligned to 256
	 * UV_Stride : Width * 2 aligned to 256
	 * Y_Scanlines: Height aligned to 32
	 * UV_Scanlines: Height/2 aligned to 16
	 * Total size = align(Y_Stride * Y_Scanlines
	 *          + UV_Stride * UV_Scanlines, 4096)
	 */
	MMM_COLOR_FMT_P010_A,
	/* P010_Y UBWC:
	 * Contains A planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 10 bit Y samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ----->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * Y_Stride = align(Width * 2, 256)
	 * Y_Scanlines = align(Height, 16)
	 * Y_UBWC_Plane_Size = align(Y_Stride * Y_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 16)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 *
	 * Total size = align(Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_P010_Y_UBWC,
	/* P010_A UBWC:
	 * Compressed Macro-tile format for NV12.
	 * Contains 4 planes in the following order -
	 * (A) Y_Meta_Plane
	 * (B) Y_UBWC_Plane
	 *
	 * Y_Meta_Plane consists of meta information to decode compressed
	 * tile data in Y_UBWC_Plane.
	 * Y_UBWC_Plane consists of Y data in compressed macro-tile format.
	 * UBWC decoder block will use the Y_Meta_Plane data together with
	 * Y_UBWC_Plane data to produce loss-less uncompressed 10 bit Y samples.
	 *
	 * Each tile in Y_UBWC_Plane/UV_UBWC_Plane is independently decodable
	 * and randomly accessible. There is no dependency between tiles.
	 *
	 * <----- Y_Meta_Stride ----->
	 * <-------- Width ------>
	 * M M M M M M M M M M M M . .      ^           ^
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      Height      |
	 * M M M M M M M M M M M M . .      |         Meta_Y_Scanlines
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      |           |
	 * M M M M M M M M M M M M . .      V           |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .                  |
	 * . . . . . . . . . . . . . .      -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . .                  V
	 * <--Compressed tile Y Stride--->
	 * <------- Width ------->
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  ^           ^
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  Height      |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |        Macro_tile_Y_Scanlines
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  |           |
	 * Y* Y* Y* Y* Y* Y* Y* Y* . . . .  V           |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .              |
	 * . . . . . . . . . . . . . . . .  -------> Buffer size aligned to 4k
	 * . . . . . . . . . . . . . . . .              V
	 *
	 * Y_Stride = align(Width * 2, 256)
	 * Y_Scanlines = align(Height, 16)
	 * Y_UBWC_Plane_Size = align(Y_Stride * Y_Scanlines, 4096)
	 * Y_Meta_Stride = align(roundup(Width, Y_TileWidth), 64)
	 * Y_Meta_Scanlines = align(roundup(Height, Y_TileHeight), 16)
	 * Y_Meta_Plane_size = align(Y_Meta_Stride * Y_Meta_Scanlines, 4096)
	 *
	 * Total size = align(Y_UBWC_Plane_size + UV_UBWC_Plane_size +
	 *           Y_Meta_Plane_size + UV_Meta_Plane_size, 4096)
	 */
	MMM_COLOR_FMT_P010_A_UBWC,
};

/*
 * Function arguments:
 * @color_fmt
 */
static __inline__ unsigned int MMM_COLOR_FMT_YUV_422_SUBSAMPLING(unsigned int color_fmt)
{
	switch (color_fmt) {
	case MMM_COLOR_FMT_P210:
	case MMM_COLOR_FMT_P210_UBWC:
		return 1;
	default:
		return 0;
	}
}

/*
 * Function arguments:
 * @color_fmt
 * @width
 * Progressive: width
 * Interlaced: width
 */
static __inline__ unsigned int MMM_COLOR_FMT_Y_STRIDE(unsigned int color_fmt,
	unsigned int width)
{
	unsigned int alignment, stride = 0;

	if (!width)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_512:
		alignment = 512;
		stride = MMM_COLOR_FMT_ALIGN(width, alignment);
		break;
	case MMM_COLOR_FMT_NV12:
	case MMM_COLOR_FMT_NV21:
	case MMM_COLOR_FMT_NV12_UBWC:
		alignment = 128;
		stride = MMM_COLOR_FMT_ALIGN(width, alignment);
		break;
	case MMM_COLOR_FMT_NV124R_UBWC:
		alignment = 256;
		stride = MMM_COLOR_FMT_ALIGN(width, alignment);
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
		alignment = 256;
		stride = MMM_COLOR_FMT_ALIGN(width, 192);
		stride = MMM_COLOR_FMT_ALIGN(stride * 4/3, alignment);
		break;
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P010:
	case MMM_COLOR_FMT_P010_A:
	case MMM_COLOR_FMT_P010_Y:
	case MMM_COLOR_FMT_P210:
	case MMM_COLOR_FMT_P210_UBWC:
	case MMM_COLOR_FMT_P010_A_UBWC:
	case MMM_COLOR_FMT_P010_Y_UBWC:
		alignment = 256;
		stride = MMM_COLOR_FMT_ALIGN(width * 2, alignment);
		break;
	case MMM_COLOR_FMT_P010_512:
		alignment = 1024;
		stride = MMM_COLOR_FMT_ALIGN(width * 2, alignment);
		break;
	default:
		break;
	}
invalid_input:
	return stride;
}

/*
 * Function arguments:
 * @color_fmt
 * @width
 * Progressive: width
 * Interlaced: width
 */
static __inline__ unsigned int MMM_COLOR_FMT_UV_STRIDE(unsigned int color_fmt,
	unsigned int width)
{
	unsigned int alignment, stride = 0;

	if (!width)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_512:
		alignment = 512;
		stride = MMM_COLOR_FMT_ALIGN(width, alignment);
		break;
	case MMM_COLOR_FMT_NV12:
	case MMM_COLOR_FMT_NV21:
	case MMM_COLOR_FMT_NV12_UBWC:
		alignment = 128;
		stride = MMM_COLOR_FMT_ALIGN(width, alignment);
		break;
	case MMM_COLOR_FMT_NV124R_UBWC:
		alignment = 256;
		stride = MMM_COLOR_FMT_ALIGN(width, alignment);
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
		alignment = 256;
		stride = MMM_COLOR_FMT_ALIGN(width, 192);
		stride = MMM_COLOR_FMT_ALIGN(stride * 4/3, alignment);
		break;
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P010:
	case MMM_COLOR_FMT_P210:
	case MMM_COLOR_FMT_P210_UBWC:
		alignment = 256;
		stride = MMM_COLOR_FMT_ALIGN(width * 2, alignment);
		break;
	case MMM_COLOR_FMT_P010_512:
		alignment = 1024;
		stride = MMM_COLOR_FMT_ALIGN(width * 2, alignment);
		break;
	default:
		break;
	}
invalid_input:
	return stride;
}

/*
 * Function arguments:
 * @color_fmt
 * @height
 * Progressive: height
 * Interlaced: (height+1)>>1
 */
static __inline__ unsigned int MMM_COLOR_FMT_Y_SCANLINES(unsigned int color_fmt,
	unsigned int height)
{
	unsigned int alignment, sclines = 0;

	if (!height)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_512:
	case MMM_COLOR_FMT_P010_512:
		alignment = 512;
		break;
	case MMM_COLOR_FMT_NV12:
	case MMM_COLOR_FMT_NV21:
	case MMM_COLOR_FMT_NV12_UBWC:
	case MMM_COLOR_FMT_P010:
	case MMM_COLOR_FMT_P010_Y:
	case MMM_COLOR_FMT_P010_A:
		alignment = 32;
		break;
	case MMM_COLOR_FMT_NV124R_UBWC:
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P010_Y_UBWC:
	case MMM_COLOR_FMT_P010_A_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
	case MMM_COLOR_FMT_P210:
		alignment = 16;
		break;
	default:
		return 0;
	}
	sclines = MMM_COLOR_FMT_ALIGN(height, alignment);
invalid_input:
	return sclines;
}

/*
 * Function arguments:
 * @color_fmt
 * @height
 * Progressive: height
 * Interlaced: (height+1)>>1
 */
static __inline__ unsigned int MMM_COLOR_FMT_UV_SCANLINES(unsigned int color_fmt,
	unsigned int height)
{
	unsigned int alignment, sclines = 0;

	if (!height)
		goto invalid_input;

	switch (color_fmt) {

	case MMM_COLOR_FMT_NV12_512:
	case MMM_COLOR_FMT_P010_512:
		alignment = 256;
		break;
	case MMM_COLOR_FMT_NV12:
	case MMM_COLOR_FMT_NV21:
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P010:
	case MMM_COLOR_FMT_NV124R_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
	case MMM_COLOR_FMT_P210:
		alignment = 16;
		break;
	case MMM_COLOR_FMT_NV12_UBWC:
		alignment = 32;
		break;
	default:
		goto invalid_input;
	}

	if (MMM_COLOR_FMT_YUV_422_SUBSAMPLING(color_fmt))
		sclines = MMM_COLOR_FMT_ALIGN(height, alignment);
	else
		sclines = MMM_COLOR_FMT_ALIGN((height+1)>>1, alignment);
invalid_input:
	return sclines;
}

/*
 * Function arguments:
 * @color_fmt
 * @width
 * Progressive: width
 * Interlaced: width
 */
static __inline__ unsigned int MMM_COLOR_FMT_Y_META_STRIDE(unsigned int color_fmt,
	unsigned int width)
{
	int y_tile_width = 0, y_meta_stride = 0;

	if (!width)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P010_A_UBWC:
	case MMM_COLOR_FMT_P010_Y_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
		y_tile_width = 32;
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
		y_tile_width = 48;
		break;
	case MMM_COLOR_FMT_NV124R_UBWC:
		y_tile_width = 64;
		break;
	default:
		goto invalid_input;
	}

	y_meta_stride = MMM_COLOR_FMT_ROUNDUP(width, y_tile_width);
	y_meta_stride = MMM_COLOR_FMT_ALIGN(y_meta_stride, 64);

invalid_input:
	return y_meta_stride;
}

/*
 * Function arguments:
 * @color_fmt
 * @height
 * Progressive: height
 * Interlaced: (height+1)>>1
 */
static __inline__ unsigned int MMM_COLOR_FMT_Y_META_SCANLINES(
		unsigned int color_fmt,	unsigned int height)
{
	int y_tile_height = 0, y_meta_scanlines = 0;

	if (!height)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_UBWC:
		y_tile_height = 8;
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
	case MMM_COLOR_FMT_NV124R_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P010_Y_UBWC:
	case MMM_COLOR_FMT_P010_A_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
		y_tile_height = 4;
		break;
	default:
		goto invalid_input;
	}

	y_meta_scanlines = MMM_COLOR_FMT_ROUNDUP(height, y_tile_height);
	y_meta_scanlines = MMM_COLOR_FMT_ALIGN(y_meta_scanlines, 16);

invalid_input:
	return y_meta_scanlines;
}

/*
 * Function arguments:
 * @color_fmt
 * @width
 * Progressive: width
 * Interlaced: width
 */
static __inline__ unsigned int MMM_COLOR_FMT_UV_META_STRIDE(unsigned int color_fmt,
	unsigned int width)
{
	int uv_tile_width = 0, uv_meta_stride = 0;

	if (!width)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
		uv_tile_width = 16;
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
		uv_tile_width = 24;
		break;
	case MMM_COLOR_FMT_NV124R_UBWC:
		uv_tile_width = 32;
		break;
	default:
		goto invalid_input;
	}

	uv_meta_stride = MMM_COLOR_FMT_ROUNDUP((width+1)>>1, uv_tile_width);
	uv_meta_stride = MMM_COLOR_FMT_ALIGN(uv_meta_stride, 64);

invalid_input:
	return uv_meta_stride;
}

/*
 * Function arguments:
 * @color_fmt
 * @height
 * Progressive: height
 * Interlaced: (height+1)>>1
 */
static __inline__ unsigned int MMM_COLOR_FMT_UV_META_SCANLINES(
		unsigned int color_fmt,	unsigned int height)
{
	int uv_tile_height = 0, uv_meta_scanlines = 0;

	if (!height)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV12_UBWC:
		uv_tile_height = 8;
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
	case MMM_COLOR_FMT_NV124R_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
		uv_tile_height = 4;
		break;
	default:
		goto invalid_input;
	}

	if (MMM_COLOR_FMT_YUV_422_SUBSAMPLING(color_fmt))
		uv_meta_scanlines = MMM_COLOR_FMT_ROUNDUP(height, uv_tile_height);
	else
		uv_meta_scanlines = MMM_COLOR_FMT_ROUNDUP((height+1)>>1, uv_tile_height);

	uv_meta_scanlines = MMM_COLOR_FMT_ALIGN(uv_meta_scanlines, 16);

invalid_input:
	return uv_meta_scanlines;
}

static __inline__ unsigned int MMM_COLOR_FMT_RGB_STRIDE(unsigned int color_fmt,
	unsigned int width)
{
	unsigned int alignment = 0, stride = 0, bpp = 4;

	if (!width)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_RGBA8888:
		alignment = 256;
		break;
	case MMM_COLOR_FMT_RGB565_UBWC:
		alignment = 256;
		bpp = 2;
		break;
	case MMM_COLOR_FMT_RGBA8888_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_8_5_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_2_1_UBWC:
	case MMM_COLOR_FMT_RGBA1010102_UBWC:
		alignment = 256;
		break;
	case MMM_COLOR_FMT_RGBA16161616F_UBWC:
		alignment = 256;
		bpp = 8;
		break;
	default:
		goto invalid_input;
	}

	stride = MMM_COLOR_FMT_ALIGN(width * bpp, alignment);

invalid_input:
	return stride;
}

static __inline__ unsigned int MMM_COLOR_FMT_RGB_SCANLINES(unsigned int color_fmt,
	unsigned int height)
{
	unsigned int alignment = 0, scanlines = 0;

	if (!height)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_RGBA8888:
		alignment = 32;
		break;
	case MMM_COLOR_FMT_RGBA8888_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_8_5_UBWC:
	case MMM_COLOR_FMT_RGBA1010102_UBWC:
	case MMM_COLOR_FMT_RGB565_UBWC:
	case MMM_COLOR_FMT_RGBA16161616F_UBWC:
		alignment = 16;
		break;
	case MMM_COLOR_FMT_RGBA8888_L_2_1_UBWC:
		alignment = 16;
		height = height / 2;
		break;
	default:
		goto invalid_input;
	}

	scanlines = MMM_COLOR_FMT_ALIGN(height, alignment);

invalid_input:
	return scanlines;
}

static __inline__ unsigned int MMM_COLOR_FMT_RGB_META_STRIDE(unsigned int color_fmt,
	unsigned int width)
{
	int rgb_tile_width = 0, rgb_meta_stride = 0;

	if (!width)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_RGBA8888_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_8_5_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_2_1_UBWC:
	case MMM_COLOR_FMT_RGBA1010102_UBWC:
	case MMM_COLOR_FMT_RGB565_UBWC:
		rgb_tile_width = 16;
		break;
	case MMM_COLOR_FMT_RGBA16161616F_UBWC:
		rgb_tile_width = 8;
		break;
	default:
		goto invalid_input;
	}

	rgb_meta_stride = MMM_COLOR_FMT_ROUNDUP(width, rgb_tile_width);
	rgb_meta_stride = MMM_COLOR_FMT_ALIGN(rgb_meta_stride, 64);

invalid_input:
	return rgb_meta_stride;
}

static __inline__ unsigned int MMM_COLOR_FMT_RGB_META_SCANLINES(
		unsigned int color_fmt,	unsigned int height)
{
	int rgb_tile_height = 0, rgb_meta_scanlines = 0;

	if (!height)
		goto invalid_input;

	switch (color_fmt) {
	case MMM_COLOR_FMT_RGBA8888_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_8_5_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_2_1_UBWC:
	case MMM_COLOR_FMT_RGBA1010102_UBWC:
	case MMM_COLOR_FMT_RGB565_UBWC:
	case MMM_COLOR_FMT_RGBA16161616F_UBWC:
		rgb_tile_height = 4;
		break;
	default:
		goto invalid_input;
	}

	rgb_meta_scanlines = MMM_COLOR_FMT_ROUNDUP(height, rgb_tile_height);
	rgb_meta_scanlines = MMM_COLOR_FMT_ALIGN(rgb_meta_scanlines, 16);

invalid_input:
	return rgb_meta_scanlines;
}

/*
 * Function arguments:
 * @color_fmt
 * @width
 * Progressive: width
 * Interlaced: width
 * @height
 * Progressive: height
 * Interlaced: height
 */
static __inline__ unsigned int MMM_COLOR_FMT_BUFFER_SIZE(unsigned int color_fmt,
	unsigned int width, unsigned int height)
{
	unsigned int size = 0;
	unsigned int y_plane, uv_plane, y_stride,
		uv_stride, y_sclines, uv_sclines;
	unsigned int y_ubwc_plane = 0, uv_ubwc_plane = 0;
	unsigned int y_meta_stride = 0, y_meta_scanlines = 0;
	unsigned int uv_meta_stride = 0, uv_meta_scanlines = 0;
	unsigned int y_meta_plane = 0, uv_meta_plane = 0;
	unsigned int rgb_stride = 0, rgb_scanlines = 0;
	unsigned int rgb_plane = 0, rgb_ubwc_plane = 0, rgb_meta_plane = 0;
	unsigned int rgb_meta_stride = 0, rgb_meta_scanlines = 0;

	if (!width || !height)
		goto invalid_input;

	y_stride = MMM_COLOR_FMT_Y_STRIDE(color_fmt, width);
	uv_stride = MMM_COLOR_FMT_UV_STRIDE(color_fmt, width);
	y_sclines = MMM_COLOR_FMT_Y_SCANLINES(color_fmt, height);
	uv_sclines = MMM_COLOR_FMT_UV_SCANLINES(color_fmt, height);
	rgb_stride = MMM_COLOR_FMT_RGB_STRIDE(color_fmt, width);
	rgb_scanlines = MMM_COLOR_FMT_RGB_SCANLINES(color_fmt, height);

	switch (color_fmt) {
	case MMM_COLOR_FMT_NV21:
	case MMM_COLOR_FMT_NV12:
	case MMM_COLOR_FMT_P010_512:
	case MMM_COLOR_FMT_P010:
	case MMM_COLOR_FMT_P210:
	case MMM_COLOR_FMT_NV12_512:
		y_plane = y_stride * y_sclines;
		uv_plane = uv_stride * uv_sclines;
		size = y_plane + uv_plane;
		break;
	case MMM_COLOR_FMT_NV12_UBWC:
	case MMM_COLOR_FMT_NV124R_UBWC:
		y_meta_stride = MMM_COLOR_FMT_Y_META_STRIDE(color_fmt, width);
		uv_meta_stride = MMM_COLOR_FMT_UV_META_STRIDE(color_fmt, width);
		if (width <= INTERLACE_WIDTH_MAX &&
			height <= INTERLACE_HEIGHT_MAX &&
			(height * width) / 256 <= INTERLACE_MB_PER_FRAME_MAX) {
			y_sclines = MMM_COLOR_FMT_Y_SCANLINES(color_fmt,
								(height+1)>>1);
			y_ubwc_plane =
				MMM_COLOR_FMT_ALIGN(y_stride * y_sclines, 4096);
			uv_sclines = MMM_COLOR_FMT_UV_SCANLINES(color_fmt,
								(height+1)>>1);
			uv_ubwc_plane =	MMM_COLOR_FMT_ALIGN(
						uv_stride * uv_sclines, 4096);
			y_meta_scanlines = MMM_COLOR_FMT_Y_META_SCANLINES(
						color_fmt, (height+1)>>1);
			y_meta_plane = MMM_COLOR_FMT_ALIGN(
				y_meta_stride * y_meta_scanlines, 4096);
			uv_meta_scanlines = MMM_COLOR_FMT_UV_META_SCANLINES(
					color_fmt, (height+1)>>1);
			uv_meta_plane = MMM_COLOR_FMT_ALIGN(uv_meta_stride *
				uv_meta_scanlines, 4096);
			size = (y_ubwc_plane + uv_ubwc_plane + y_meta_plane +
				uv_meta_plane)*2;
		} else {
			y_sclines = MMM_COLOR_FMT_Y_SCANLINES(color_fmt,
									height);
			y_ubwc_plane =
				MMM_COLOR_FMT_ALIGN(y_stride * y_sclines, 4096);
			uv_sclines = MMM_COLOR_FMT_UV_SCANLINES(color_fmt,
									height);
			uv_ubwc_plane =
				MMM_COLOR_FMT_ALIGN(uv_stride * uv_sclines,
									4096);
			y_meta_scanlines = MMM_COLOR_FMT_Y_META_SCANLINES(
							color_fmt, height);
			y_meta_plane = MMM_COLOR_FMT_ALIGN(
				y_meta_stride * y_meta_scanlines, 4096);
			uv_meta_scanlines = MMM_COLOR_FMT_UV_META_SCANLINES(
							color_fmt, height);
			uv_meta_plane = MMM_COLOR_FMT_ALIGN(uv_meta_stride *
				uv_meta_scanlines, 4096);
			size = (y_ubwc_plane + uv_ubwc_plane + y_meta_plane +
				uv_meta_plane);
		}
		break;
	case MMM_COLOR_FMT_NV12_BPP10_UBWC:
	case MMM_COLOR_FMT_P010_UBWC:
	case MMM_COLOR_FMT_P210_UBWC:
		y_ubwc_plane = MMM_COLOR_FMT_ALIGN(y_stride * y_sclines, 4096);
		uv_ubwc_plane = MMM_COLOR_FMT_ALIGN(uv_stride * uv_sclines,
									4096);
		y_meta_stride = MMM_COLOR_FMT_Y_META_STRIDE(color_fmt, width);
		y_meta_scanlines = MMM_COLOR_FMT_Y_META_SCANLINES(color_fmt,
									height);
		y_meta_plane = MMM_COLOR_FMT_ALIGN(
				y_meta_stride * y_meta_scanlines, 4096);
		uv_meta_stride = MMM_COLOR_FMT_UV_META_STRIDE(color_fmt, width);
		uv_meta_scanlines = MMM_COLOR_FMT_UV_META_SCANLINES(color_fmt,
									height);
		uv_meta_plane = MMM_COLOR_FMT_ALIGN(uv_meta_stride *
					uv_meta_scanlines, 4096);

		size = y_ubwc_plane + uv_ubwc_plane + y_meta_plane +
			uv_meta_plane;
		break;
	case MMM_COLOR_FMT_RGBA8888:
		rgb_plane = MMM_COLOR_FMT_ALIGN(rgb_stride  * rgb_scanlines,
									4096);
		size = rgb_plane;
		break;
	case MMM_COLOR_FMT_RGBA8888_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_8_5_UBWC:
	case MMM_COLOR_FMT_RGBA8888_L_2_1_UBWC:
	case MMM_COLOR_FMT_RGBA1010102_UBWC:
	case MMM_COLOR_FMT_RGB565_UBWC:
	case MMM_COLOR_FMT_RGBA16161616F_UBWC:
		rgb_ubwc_plane = MMM_COLOR_FMT_ALIGN(rgb_stride * rgb_scanlines,
							4096);
		rgb_meta_stride = MMM_COLOR_FMT_RGB_META_STRIDE(color_fmt,
									width);
		rgb_meta_scanlines = MMM_COLOR_FMT_RGB_META_SCANLINES(color_fmt,
					height);
		rgb_meta_plane = MMM_COLOR_FMT_ALIGN(rgb_meta_stride *
					rgb_meta_scanlines, 4096);
		size = rgb_ubwc_plane + rgb_meta_plane;
		break;
	case MMM_COLOR_FMT_P010_Y:
	case MMM_COLOR_FMT_P010_A:
		y_plane = y_stride * y_sclines;
		size = y_plane;
		break;
	case MMM_COLOR_FMT_P010_Y_UBWC:
	case MMM_COLOR_FMT_P010_A_UBWC:
		y_ubwc_plane = MMM_COLOR_FMT_ALIGN(y_stride * y_sclines, 4096);
		y_meta_stride = MMM_COLOR_FMT_Y_META_STRIDE(color_fmt, width);
		y_meta_scanlines = MMM_COLOR_FMT_Y_META_SCANLINES(color_fmt,
									height);
		y_meta_plane = MMM_COLOR_FMT_ALIGN(
				y_meta_stride * y_meta_scanlines, 4096);
		size = y_ubwc_plane + y_meta_plane;
		break;
	default:
		break;
	}
invalid_input:
	return MMM_COLOR_FMT_ALIGN(size, 4096);
}

static __inline__ unsigned int MMM_COLOR_FMT_BUFFER_SIZE_USED(
		unsigned int color_fmt,	unsigned int width,
		unsigned int height, unsigned int interlace)
{
	unsigned int size = 0;
	unsigned int y_stride, uv_stride, y_sclines, uv_sclines;
	unsigned int y_ubwc_plane = 0, uv_ubwc_plane = 0;
	unsigned int y_meta_stride = 0, y_meta_scanlines = 0;
	unsigned int uv_meta_stride = 0, uv_meta_scanlines = 0;
	unsigned int y_meta_plane = 0, uv_meta_plane = 0;

	if (!width || !height)
		goto invalid_input;

	if (!interlace && (color_fmt == MMM_COLOR_FMT_NV12_UBWC ||
	    color_fmt == MMM_COLOR_FMT_NV124R_UBWC)) {
		y_stride = MMM_COLOR_FMT_Y_STRIDE(color_fmt, width);
		uv_stride = MMM_COLOR_FMT_UV_STRIDE(color_fmt, width);
		y_sclines = MMM_COLOR_FMT_Y_SCANLINES(color_fmt, height);
		y_ubwc_plane = MMM_COLOR_FMT_ALIGN(y_stride * y_sclines, 4096);
		uv_sclines = MMM_COLOR_FMT_UV_SCANLINES(color_fmt, height);
		uv_ubwc_plane = MMM_COLOR_FMT_ALIGN(uv_stride * uv_sclines,
									4096);
		y_meta_stride = MMM_COLOR_FMT_Y_META_STRIDE(color_fmt, width);
		y_meta_scanlines =
			MMM_COLOR_FMT_Y_META_SCANLINES(color_fmt, height);
		y_meta_plane = MMM_COLOR_FMT_ALIGN(
			y_meta_stride * y_meta_scanlines, 4096);
		uv_meta_stride = MMM_COLOR_FMT_UV_META_STRIDE(color_fmt, width);
		uv_meta_scanlines =
			MMM_COLOR_FMT_UV_META_SCANLINES(color_fmt, height);
		uv_meta_plane = MMM_COLOR_FMT_ALIGN(uv_meta_stride *
			uv_meta_scanlines, 4096);
		size = (y_ubwc_plane + uv_ubwc_plane + y_meta_plane +
			uv_meta_plane);
		size = MMM_COLOR_FMT_ALIGN(size, 4096);
	} else {
		size = MMM_COLOR_FMT_BUFFER_SIZE(color_fmt, width, height);
	}
invalid_input:
	return size;
}

#endif
